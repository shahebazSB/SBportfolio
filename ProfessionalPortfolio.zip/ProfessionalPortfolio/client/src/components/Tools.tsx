import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

export default function Tools() {
  const tools = [
    {
      name: "Selenium",
      description: "Automation Testing Framework",
      icon: "🔄"
    },
    {
      name: "Postman",
      description: "API Testing Tool",
      icon: "🚀"
    },
    {
      name: "Jenkins",
      description: "CI/CD Pipeline",
      icon: "⚙️"
    },
    {
      name: "JMeter",
      description: "Performance Testing Tool",
      icon: "📊"
    },
    {
      name: "Azure DevOps",
      description: "Project Management & CI/CD",
      icon: "🔷"
    },
    {
      name: "Git",
      description: "Version Control",
      icon: "📝"
    },
    {
      name: "JIRA",
      description: "Project Management",
      icon: "📌"
    }
  ];

  return (
    <section id="tools" className="py-16 bg-muted/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-8 text-center">Tools & Technologies</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map((tool, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="p-6 flex flex-col items-center text-center">
                    <span className="text-4xl mb-4">{tool.icon}</span>
                    <h3 className="text-xl font-semibold mb-2">{tool.name}</h3>
                    <p className="text-muted-foreground">{tool.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}