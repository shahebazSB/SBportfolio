import { motion } from "framer-motion";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Projects() {
  const projects = [
    {
      title: "E-commerce Automation Suite",
      description: "Developed and maintained a comprehensive automated testing framework for an e-commerce platform using Selenium WebDriver and TestNG.",
      tools: ["Selenium", "Java", "TestNG", "Maven", "Jenkins"],
      type: "Automation Testing"
    },
    {
      title: "API Security Testing Project",
      description: "Conducted thorough security testing of RESTful APIs using various tools to identify vulnerabilities and ensure data protection.",
      tools: ["Postman", "OWASP ZAP", "Burp Suite", "JMeter"],
      type: "Security Testing"
    },
    {
      title: "Mobile App Testing",
      description: "Led manual testing efforts for a cross-platform mobile application, ensuring functionality across different devices and OS versions.",
      tools: ["Appium", "Android Studio", "iOS Simulator", "JIRA"],
      type: "Manual Testing"
    }
  ];

  return (
    <section id="projects" className="py-16">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-8 text-center">Projects</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow duration-300">
                  <CardHeader>
                    <Badge className="w-fit mb-2">{project.type}</Badge>
                    <h3 className="text-xl font-semibold">{project.title}</h3>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.tools.map((tool, i) => (
                        <Badge key={i} variant="outline">{tool}</Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
