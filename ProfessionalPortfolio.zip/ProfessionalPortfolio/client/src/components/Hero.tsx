import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="min-h-[calc(100vh-4rem)] relative flex items-center bg-background">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-primary/5" />
      <div className="container mx-auto px-4 relative">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl flex-1"
          >
            <motion.h1 
              className="text-4xl md:text-6xl font-bold mb-4"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              Shahebaz Bagwan
            </motion.h1>
            <motion.h2
              className="text-xl md:text-3xl mb-6 text-primary"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              QA Engineer
              <span className="block text-lg md:text-xl mt-2 text-muted-foreground">
                Specializing in Manual & Automation Testing
              </span>
            </motion.h2>
            <motion.p
              className="text-lg text-muted-foreground"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              Dedicated to ensuring software quality through comprehensive testing methodologies
            </motion.p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="relative"
          >
            <div className="w-64 h-64 md:w-80 md:h-80 relative">
              {/* Animated gradient background */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 via-primary/10 to-primary/5 animate-pulse" />
              {/* Placeholder until image is uploaded */}
              <div className="absolute inset-0 rounded-full border-4 border-primary/20 p-1 bg-background/80 flex items-center justify-center">
                <span className="text-6xl text-primary/40">SB</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}