import { ReactNode } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function Layout({ children }: { children: ReactNode }) {
  const links = [
    { href: "#about", label: "About" },
    { href: "#experience", label: "Experience" },
    { href: "#education", label: "Education" },
    { href: "#skills", label: "Skills" },
    { href: "#tools", label: "Tools" },
    { href: "#projects", label: "Projects" },
    { href: "#contact", label: "Contact" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="fixed top-0 w-full z-50 bg-gradient-to-r from-primary/10 via-background to-primary/10 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-primary/20">
        <nav className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/">
            <a className="font-bold text-2xl text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/70 hover:to-primary transition-colors duration-300">
              Shahebaz Bagwan
            </a>
          </Link>

          <div className="hidden md:flex space-x-1">
            {links.map((link) => (
              <Button
                key={link.href}
                variant="ghost"
                size="sm"
                asChild
                className="hover:bg-primary/10 transition-colors duration-300"
              >
                <a 
                  href={link.href}
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-primary"
                  )}
                >
                  {link.label}
                </a>
              </Button>
            ))}
          </div>
        </nav>
      </header>
      <main className="pt-16">
        {children}
      </main>
    </div>
  );
}