import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  GithubIcon, 
  LinkedinIcon, 
  InstagramIcon, 
  DownloadIcon,
  CalendarIcon,
  MapPinIcon,
  GlobeIcon,
  UserIcon
} from "lucide-react";

export default function About() {
  const socialLinks = [
    {
      icon: <LinkedinIcon className="w-5 h-5" />,
      label: "LinkedIn",
      href: "https://www.linkedin.com/in/shahebaz-bagwan-7a1168322"
    },
    {
      icon: <GithubIcon className="w-5 h-5" />,
      label: "GitHub",
      href: "https://github.com/shahebazSB"
    },
    {
      icon: <InstagramIcon className="w-5 h-5" />,
      label: "Instagram",
      href: "https://www.instagram.com/shahebaz_sb_10"
    }
  ];

  return (
    <section id="about" className="py-16 bg-gradient-to-br from-primary/5 via-background to-primary/5">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-8 text-center">About Me</h2>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex flex-col items-center">
                  <h3 className="text-xl font-semibold mb-6">Personal Details</h3>
                  <div className="space-y-4 w-full">
                    <div className="flex items-center gap-3">
                      <CalendarIcon className="w-5 h-5 text-primary" />
                      <span><strong>Date of Birth:</strong> 03 Nov 2003</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <MapPinIcon className="w-5 h-5 text-primary" />
                      <div className="flex flex-col">
                        <span><strong>Current Address:</strong></span>
                        <span className="text-muted-foreground">Mehdipatnam, Hyderabad, Telangana</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <MapPinIcon className="w-5 h-5 text-primary" />
                      <div className="flex flex-col">
                        <span><strong>Permanent Address:</strong></span>
                        <span className="text-muted-foreground">Partur, Maharashtra (431501)</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <GlobeIcon className="w-5 h-5 text-primary" />
                      <span><strong>Languages:</strong> English, Hindi, Marathi</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <UserIcon className="w-5 h-5 text-primary" />
                      <span><strong>Nationality:</strong> Indian</span>
                    </div>
                  </div>
                  <div className="mt-6 w-full">
                    <Button 
                      className="w-full gap-2 hover:bg-primary/90 transition-colors" 
                      asChild
                    >
                      <a 
                        href="https://github.com/shahebazSB/Resume-Shahebaz-Bagwam-"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <DownloadIcon className="w-4 h-4" />
                        Download Resume
                      </a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-6">Professional Summary</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  As a QA Engineer, I specialize in ensuring software quality through comprehensive testing methodologies. 
                  My approach combines attention to detail with a deep understanding of user experience to deliver 
                  reliable and robust applications.
                </p>

                <div className="flex flex-wrap gap-3">
                  {socialLinks.map((link, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="gap-2 hover:bg-primary/10 transition-colors"
                      asChild
                    >
                      <a 
                        href={link.href} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center"
                      >
                        {link.icon}
                        {link.label}
                      </a>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </section>
  );
}