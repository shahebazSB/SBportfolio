import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, School, Calendar } from "lucide-react";

export default function Education() {
  const education = [
    {
      degree: "B.SC (Computer Science)",
      institution: "Dr.B.A.M University",
      year: "2024",
      percentage: "61.77%",
      icon: <GraduationCap className="w-8 h-8 text-primary" />
    },
    {
      degree: "HSC",
      institution: "Maharashtra State Board",
      year: "2021",
      percentage: "81.17%",
      icon: <School className="w-8 h-8 text-primary" />
    },
    {
      degree: "SSC",
      institution: "Maharashtra State Board",
      year: "2019",
      percentage: "71.40%",
      icon: <School className="w-8 h-8 text-primary" />
    }
  ];

  return (
    <section id="education" className="py-16 bg-gradient-to-br from-primary/5 via-background to-primary/5">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-8 text-center">Education Journey</h2>

          <div className="space-y-6 max-w-3xl mx-auto relative">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-primary/20" />

            {education.map((edu, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
              >
                <Card className="relative ml-16 hover:shadow-lg transition-shadow duration-300">
                  {/* Timeline dot */}
                  <div className="absolute -left-16 top-6 bg-background p-2 rounded-full border-2 border-primary">
                    {edu.icon}
                  </div>

                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{edu.degree}</h3>
                    <p className="text-muted-foreground">{edu.institution}</p>
                    <div className="flex items-center justify-between mt-2 text-sm">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {edu.year}
                      </span>
                      <span className="font-medium">{edu.percentage}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}